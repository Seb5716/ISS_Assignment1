#!/bin/bash
File=Amogus.txt
Filesize=$( stat -c%s "$File")
echo "Size of $File = $Filesize bytes."
wc -l < $File
wc -w < $File
linenum=1
while read line;do
	printf "$linenum: $(echo $line | wc -w)"
	((linenum++))
done
