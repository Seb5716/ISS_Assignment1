#!/bin/bash
read var1
strlen=${#var1}
for (( i=$strlen-1; i>=0; i-- ));
do
    revstr=$revstr${var1:$i:1}
done
echo "Original String : $var1"
echo "Reversed String : $revstr"
revstr=$(echo "$revstr" | tr "0-9a-z" "1-9a-z_")
echo "$revstr"
read var2
length=${#var2}
half=$(( length/2 ))
half1=${var2:0:half}
for (( i=$half-1; i>=0; i-- ));
do
    revhalf1=$revhalf1${half1:$i:1}
done

half2=${var2:half:half}
final="${revhalf1} ${half2}"
echo "$final"
