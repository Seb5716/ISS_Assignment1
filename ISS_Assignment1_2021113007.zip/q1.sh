#!/bin/bash
grep . quotes.txt
sort quotes.txt | uniq -u	
